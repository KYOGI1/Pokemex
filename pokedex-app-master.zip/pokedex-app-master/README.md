# Pokedex using Angular and Bootstrap with PokeAPI

Creating a Pokedex with the help of PokeAPI, Angular and Bootstrap.

Check out the CodeOmelet blog post for this project.

Demo: http://funpokedex.netlify.app/

Link: https://codeomelet.com/posts/pokedex-using-angular-and-bootstrap-with-pokeapi

API in use:
```
https://pokeapi.co/
https://pokeres.bastionbot.org/
```
